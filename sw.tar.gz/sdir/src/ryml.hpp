#ifndef _RYML_HPP_
#define _RYML_HPP_

#include "c4/yml/yml.hpp"

namespace ryml {
using namespace c4::yml;
using namespace c4;
}

#endif /* _RYML_HPP_ */
